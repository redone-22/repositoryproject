"use strict";
/*global $ */
$(document).ready(function () { $("body").fadeIn(3000);
                               $("img").click(function () { $("img").fadeOut(3000); });
                              });