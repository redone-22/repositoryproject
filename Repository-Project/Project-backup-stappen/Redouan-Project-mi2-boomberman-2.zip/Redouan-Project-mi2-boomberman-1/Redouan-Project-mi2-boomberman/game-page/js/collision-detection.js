"use strict";
/*global $ */
var image;
var stone;
var stoneLeft;
var stoneRight;
var stoneAbove;
var stoneUnder;
var player;
var player_collision;
var playerLeft;
var playerRight;
var playerAbove;
var playerUnder;

$(document).keydown(function (e) {
	
    
	platform();

});

function platform() {
	var platform = $('#gamePlatform').position();
	var platformLeft = platform.left;
	var platformRight = platformLeft + $('#gamePlatform').width();
	var platformAbove = platform.top;
	var platformUnder = platformAbove + $('#gamePlatform').height();
    
    var stone = $('.stone').position();
    var stones = $('.stone');
    
	var stoneLeft = stone.left;
	var stoneRight = stoneLeft + $('.stone').width();
	var stoneAbove = stone.top;
	var stoneUnder = stoneAbove + $('.stone').height();
    
    if ((playerRight > stoneLeft ) &&  (playerRight < stoneRight ) && (playerAbove > stoneAbove - 55) && (playerUnder < stoneUnder + 40)) moveRight2 = false;
	else moveRight2 = true;
    
	if ((playerLeft < stoneRight ) &&  (playerLeft > stoneLeft ) && (playerAbove > stoneAbove - 55) && (playerUnder < stoneUnder + 40)) moveLeft2 = false;
	else moveLeft2 = true;

    if((playerAbove < stoneUnder) && (playerAbove > stoneAbove) && ( playerLeft > stoneLeft - 40) && (playerRight < stoneRight + 40)) moveUp2 = false;
	else moveUp2 = true;

    if((playerUnder > stoneAbove) && (playerUnder < stoneUnder) && ( playerLeft > stoneLeft - 40) && (playerRight < stoneRight + 40)) moveDown2 = false;
	else moveDown2 = true;
 
    if (playerLeft  < platformLeft) moveLeft = false;
	else moveLeft = true;

	if(playerRight > platformRight) moveRight = false;
	else moveRight = true;

	if(playerAbove - 8  < platformAbove) moveUp = false;
	else moveUp = true;

	if(playerUnder - 10> platformUnder) moveDown = false;
	else moveDown = true;
}
$(document).keydown(function (e) {

	image = $("#bomber").attr("src");

	var player = $("#bomber");
	var playerPosition = $("#bomber").position();

	player_collision = { x_left: playerPosition.left, y_top: playerPosition.top, breedte: player.width(), lengte: player.height() };

	playerLeft = player_collision.x_left;
	playerRight = player_collision.x_left + player_collision.breedte;
	playerAbove = player_collision.y_top;
	playerUnder = player_collision.y_top + player_collision.lengte;

	platform();
});