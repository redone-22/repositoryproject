"use strict";
/*global $ */
var totres;
function scoreUp(var scoren){
    totres = scoren;
            document.getElementById('score').innerHTML = totres;
}